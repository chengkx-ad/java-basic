package ckx;

/*
    for循环和while循环对比



 */

public class p6 {
}
