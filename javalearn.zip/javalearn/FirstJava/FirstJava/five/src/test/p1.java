package test;

// 长方形的周长

public class p1 {
    public static void main(String[] args) {
    Sums(1, 2);

    }

    public static void Sums(int len, int width){
        int res = (len + width) * 2;
        }
}
