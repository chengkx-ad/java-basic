package ckx.demo;

// 数组的动态初始化

public class p2 {
    public static void main(String[] args) {
        // 动态初始化格式
        // int[] arr = new int[数组长度]
        int[] arr = new int[3];
    }
}

// 数组的常见问题
// 当我们访问了数组中不存在的索引，就会发生索引越界异常
