package ckx.demo1;

import com.sun.jdi.PathSearchingVirtualMachine;

public class helloworld {
    public static void main(String[] args) {
        System.out.println("HelloWorld");


    }


}
