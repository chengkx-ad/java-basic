package ckx.demo1;

public class YunSuAnFu1 {
    public static void main(String[] args) {
        // +
        System.out.println(3 + 2); // 5
        // -
        System.out.println(5 - 1); // 4
        // *
        System.out.println(5 * 2); // 10

        //如果有小数，代码结果有可能不精确
        System.out.println(1.1 + 1.01);



    }
}
