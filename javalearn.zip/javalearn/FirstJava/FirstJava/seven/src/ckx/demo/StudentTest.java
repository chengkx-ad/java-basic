package ckx.demo;

public class StudentTest {
    public static void main(String[] args) {
        // student s = new student();
        student s = new student("s", 20);
        System.out.println(s.getName());
        System.out.println(s.getAge());


    }
}
