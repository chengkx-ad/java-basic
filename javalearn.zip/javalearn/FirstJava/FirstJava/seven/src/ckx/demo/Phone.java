package ckx.demo;

public class Phone {
    // 如何定义类？

    String brand;
    double price;


    public void call() {
        System.out.println("手机在打电话");
    }
    public void PlayGame() {
        System.out.println("手机在玩游戏");
    }
}
