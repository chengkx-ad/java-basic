package test;

// 交换数组
// 打乱数据

public class p5 {
    public static void main(String[] args) {
        int arr[] = {1,2,3,4,5};
        for (int i = 0; i < arr.length; i++) {

        }
    }
    
}
