package ckx.demo1;
// 三元运算符
public class sanyuanyunsuan {

}
