package ckx.demo;

/*
static
继承
包、final、权限修饰符、代码块
抽象类
接口
多态
内部类
拼图小游戏
*/


public class P1 {




}
