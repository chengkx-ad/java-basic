package demo3;

public interface English {

    public abstract void speakEnglish();


}
