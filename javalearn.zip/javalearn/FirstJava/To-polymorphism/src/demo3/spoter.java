package demo3;

public abstract class spoter extends person{

    public spoter() {
    }

    public spoter(String name, int age) {
        super(name, age);
    }

    public abstract void study();

}
