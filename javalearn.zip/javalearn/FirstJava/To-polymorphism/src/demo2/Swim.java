package demo2;

public interface Swim {

    public abstract void swim();


}
